import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PokemonComponent } from './pokemon.component';
import { MainComponent } from './main/main.component';



@NgModule({
  declarations: [
    PokemonComponent,
    MainComponent
  ],
  exports:[
MainComponent,
PokemonComponent
  ],
  imports: [
    CommonModule
  ]
})
export class PokemonModule { }
