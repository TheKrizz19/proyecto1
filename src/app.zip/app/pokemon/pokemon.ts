export interface Pokemon {
    nombre: string;
    pc: number;
}
